/* function result(){
    //alert('Clicked');
    var price = parseInt(document.getElementById("prc").value);
    var quantity = parseInt(document.getElementById("quan").value);
    var tax = parseInt(document.getElementById("tax").value)
    var grossamt =parseInt(price*quantity);
    var result = grossamt+(grossamt*tax)/100;
    // document.write("<br/>price"+price);
    // document.write("<br/>quant"+quantity);
    // document.write("<br/>tax"+tax);
    // document.write("<br/>gm"+grossamt);
    // document.write("<br/>res"+result);
    document.getElementById("res").value=result;

    
} */

function result(){
    var price = parseInt(document.getElementById("prc").value);
    var quantity = parseInt(document.getElementById("quan").value);
    var tax = parseInt(document.getElementById("tax").value)
    var a =parseInt(price*quantity);
    var b = (a*tax)/100;
    var result = a + b
    document.getElementById("res").value=result;

    
}
