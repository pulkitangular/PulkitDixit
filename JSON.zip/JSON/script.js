
    /* var http = new XMLHttpRequest()
    http.open("GET", "UseAJAX/pets.json")
    http.send()
    http.onreadystatechange= function(){
        if(this.readyState==4 && this.status==200)
    {
        var result = JSON.parse(this.response)
        console.log(result)
    }
} */
function loadpets(){
    fetch("UseAJAX/pets.json").then(function(res){
        if(res.ok){
            res.json().then(function(result){
                console.log(result)
            })
        }
    })

}
 function show(pets){
     var table= document.getElementById("tbl1");
     for (var i=0; i < pets.length; i++){
        var obj = pets[i]
        console.log(obj)
        var row= document.createElement('tr')
        var name= document.createElement('td')
        var age= document.createElement('td')
        var color= document.createElement('td')
        var weight= document.createElement('td')

        name.innerHTML=obj.name
        name.innerHTML=obj.age
        name.innerHTML=obj.color
        name.innerHTML=obj.weight

        row.appendChild(name)
        row.appendChild(age)
        row.appendChild(color)
        row.appendChild(weight)

        table.appendChild(row)
     }
 }
    window.onload = loadpets

// loadpets()