var a = prompt("Enter a string");
var b = prompt("find out each word");

function countString(c, d) {
    let count = 0;

    for (let i = 0; i < c.length; i++) {

        if (c.charAt(i) == d) {
        count += 1;
        }
    }
    return count;
}

console.log(countString(a, b));