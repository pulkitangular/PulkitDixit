var x =new String("rajesh12345@gamil.com")
    x = x.split("")
    x.splice(0,21,"raj********@gmail.com")
    console.log(x);


    //second spread method 
    var y =new String("rajesh12345@gamil.com")
        y = y.split("")
        y.splice(0,21,..."raj********@gmail.com".split("")) 
        console.log(y);

        console.log(y.join(""));