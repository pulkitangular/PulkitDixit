function pet(){
   event.preventDefault()
   var b=serialize(this)
   console.log(b)
}
   function serialize(frm){
    var pets={}
    var obj = new FormData(frm)
    obj.forEach((e,k)=>{
        pets[k]=e
    })
    return pets            
}
document.getElementById("frm").addEventListener('submit', pet)