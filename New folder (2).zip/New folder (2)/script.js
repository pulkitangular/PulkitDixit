var data;
function loadproduct() {
    var http = new XMLHttpRequest()
    http.open("GET", "data/product.json")
    http.send()
    http.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var result = JSON.parse(this.response)
            console.log(result)
            data = result.product
        }
        BindItem(data)
    }
}
loadproduct()

function BindItem(arr) {
    var temp = ``
    arr.forEach((e) => {
        temp += `<div class="col-4"><div class="card">
        <div class="card-body">
        <img src="{}" alt="" width="500" height="600">
        <h2 class="card-text">Title:${e.title}</h2>
        <h4 class="card-title">ID:${e.id}</h4>
        <p class="card-text">Price:${e.price}</p>
        <div class="img"><img src="${e.image}"/></div>
        <p class="card-text">Description:"${e.description}"</p>
        </div>
        </div>
        </div>`
    })
    document.querySelector(".post").innerHTML = temp;
}