//Spread Operator

var nums = [1, 2, 3];
var nums2 = [...nums];
var nums3 = nums.slice();
var nums4 = [].concat(nums)
console.log(nums)
console.log(nums2)
console.log(nums3)
console.log(nums4)