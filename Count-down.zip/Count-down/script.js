const time = document.querySelector("p")
let timeSec = 30;


time.innerHTML= `00:$(timeSec)`;
const countDown = setInterval(()=>{
    timeSec--;
    time.innerHTML= `00:${timeSec}`
    if(timeSec <= 0 || timeSec <1){
    endTime();
    clearInterval(countDown);   
    }
    
},1000)
function endTime(){
    time.innerHTML= "Time&nbsp;Out"
}

