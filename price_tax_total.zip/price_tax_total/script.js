/* function init(){
    var name ="Mozilla";
    function displayName(){
        alert(name);
    }
    displayName()
}
init(); */

function calculate(){
    var n1 = parseInt(document.getElementById("inp1").value)
    var n2 = parseInt(document.getElementById("inp2").value)
    var n3 = parseInt(document.getElementById("inp3").value)
    var n4 = n1*n2
    var result = n1+((n4*n3)/100)

    document.getElementById("inp4").value=result
}