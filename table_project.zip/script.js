function redcolor(){
    document.getElementById("maintext").style.color="Red"
    }
document.getElementById("btn").addEventListener("click", redcolor)

function bluecolor(){
    document.getElementById("maintext").style.color="Blue"
    }
    document.getElementById("btn1").addEventListener("click", bluecolor)

function greencolor(){
    document.getElementById("maintext").style.color="green"
    }
    document.getElementById("btn2").addEventListener("click", greencolor)



function font_Size(){
    //document.getElementsByClassName("demo")[0].style.fontSize="20px"
    document.getElementById("maintext").style.fontSize="20px"
    }
document.getElementById("btn3").addEventListener("click", font_Size)

function fontSize(){
    document.getElementById("maintext").style.fontSize="30px"
    }
document.getElementById("btn4").addEventListener("click", fontSize)

function fntSize(){
    document.getElementById("maintext").style.fontSize="40px"
    }
document.getElementById("btn5").addEventListener("click", fntSize)


function font_family(){
    document.getElementById("maintext").style.fontFamily="Verdana"
}
    document.getElementById("btn6").addEventListener("click", font_family)

function fntfamily(){
        document.getElementById("maintext").style.fontFamily="Arial"
    }
        document.getElementById("btn7").addEventListener("click", fntfamily)

function fnfamily(){
    document.getElementById("maintext").style.fontFamily="Univers"
}
    document.getElementById("btn8").addEventListener("click", fnfamily)


