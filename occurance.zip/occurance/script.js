/* var x ="India's captial is Delhi, Delhi is a beautiful city";
word = "Delhi";

function countoccurences(x, word){
    var y = x.split(" ")
    var count = 0;
    for (var i = 0; i < y.length; i++){
        if (word==(y[i]))
        count++
    }
    return count;
}
    result = countoccurences(x, word);

console.log(result);

 */

var x ="India's captial is Delhi, Delhi is a beautiful city";
var y = x.
console.log